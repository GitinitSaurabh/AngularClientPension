    export interface IProcessedPension {
        id: number;
        pensionAmount: number;
        bankServiceCharge: number;
    }
