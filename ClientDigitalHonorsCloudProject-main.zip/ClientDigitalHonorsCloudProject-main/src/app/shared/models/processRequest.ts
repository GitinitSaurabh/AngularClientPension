
export interface IProcessRequest {
        id: number;
        aadhaarNumber: string;
    }
  

    export class ProcessRequest implements IProcessRequest{
        id: number;
        aadhaarNumber: string;
}

