export const environment = {
  production: true,
  // pensionerDetailApi: 'http://20.204.241.170/api/PensionerDetail/getPensionerDetails',
  authApi: 'http://20.204.241.170/api/auth',
  processPensionApi: 'http://20.204.241.184/api/ProcessPension'

};
